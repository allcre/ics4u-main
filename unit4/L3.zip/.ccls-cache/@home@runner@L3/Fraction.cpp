#include "Fraction.h"
#include <cstdlib>
#include <algorithm>

int Fraction::numOfFractions = 0;

Fraction::Fraction() {
  numerator = 1;
  denominator = 1;
  numOfFractions++;
}

Fraction::Fraction(int num, int den) {
  setNumerator(num);
  setDenominator(den);
  numOfFractions++;
}

Fraction::Fraction(const Fraction &f) {
  setNumerator(f.numerator);
  setDenominator(f.denominator);
}

int Fraction::getNumerator() {
  return numerator;
}

int Fraction::getDenominator() {
  return denominator;
}

void Fraction::setNumerator(int n) {
  this->numerator = n;
}

void Fraction::setDenominator(int d) {
  if (d < 0)
    numerator *= -1;
    
  this->denominator = abs(d);
}

string Fraction::toString() {
  if (denominator == 0)
      return "undefined";
  else
    return (to_string(numerator) + " / " + to_string(denominator));
}

int Fraction::numF() {
  return numOfFractions;
}

int lcm(int a, int b) {
  return (a * b)/__gcd(a, b);
}

void Fraction::simplify() {
  int gcd = __gcd(numerator, denominator);
  numerator /= gcd;
  denominator /= gcd;
  if (denominator < 0) {
    numerator *= -1;
    denominator *= -1;
  }
  else if (denominator == 0) {
    numerator = 0;
  }
}

void Fraction::add(const Fraction f) {
  int lcm = ::lcm(this->denominator, f.denominator);
  int num1 = this->numerator * (lcm / this->denominator);
  int num2 = f.numerator * (lcm / f.denominator);
  int num = num1 + num2;
  this->numerator = num;
  this->denominator = lcm;
  simplify();
}

void Fraction::subtract(const Fraction &f) {
  int lcm = ::lcm(this->denominator, f.denominator);
  int num1 = this->numerator * (lcm / this->denominator);
  int num2 = f.numerator * (lcm / f.denominator);
  int num = num1 - num2;
  this->numerator = num;
  this->denominator = lcm;
  simplify();
}

void Fraction::multiply(const Fraction &f) {
  this->numerator *= f.numerator;
  this->denominator *= f.denominator;
  simplify();
}

void Fraction::divide(const Fraction &f) {
  this->numerator *= f.denominator;
  this->denominator *= f.numerator;
  simplify();
}

Fraction Fraction::add(Fraction f, Fraction g) {
  int lcm = ::lcm(f.denominator, g.denominator);
  int num1 = f.numerator * (lcm / f.denominator);
  int num2 = g.numerator * (lcm / g.denominator);
  int num = num1 + num2;
  Fraction newf = ::Fraction(num, lcm);
  newf.simplify();
  return newf;
}

Fraction Fraction::subtract(Fraction f, Fraction g) {
  int lcm = ::lcm(f.denominator, g.denominator);
  int num1 = f.numerator * (lcm / f.denominator);
  int num2 = g.numerator * (lcm / g.denominator);
  int num = num1 - num2;
  Fraction newf = ::Fraction(num, lcm);
  newf.simplify();
  return newf;
}

Fraction Fraction::multiply(Fraction f, Fraction g) {
  int num = f.numerator * g.numerator;
  int den = f.denominator * g.denominator;
  Fraction newf = ::Fraction(num, den);
  newf.simplify();
  return newf;
}

Fraction Fraction::divide(Fraction f, Fraction g) {
  int num = f.numerator * g.denominator;
  int den = f.denominator * g.numerator;
  Fraction newf = ::Fraction(num, den);
  newf.simplify();
  return newf;
}