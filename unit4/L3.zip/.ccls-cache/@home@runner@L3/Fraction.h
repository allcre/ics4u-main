#include <iostream>
using namespace std;

#ifndef FRACTION_H
#define FRACTION_H

class Fraction 
{
  private: 
    int numerator, denominator;
    static int numOfFractions;

  public:
    Fraction();
    Fraction(int num, int den);
    Fraction(const Fraction &f);
    int getNumerator();
    int getDenominator();
    void setNumerator(int n);
    void setDenominator(int d);
    string toString();
    void add(const Fraction f);
    void subtract(const Fraction& f);
    void multiply(const Fraction& f);
    void divide(const Fraction& f);
    void simplify();
    static Fraction add(Fraction f, Fraction g);
    static Fraction subtract(Fraction f, Fraction g);
    static Fraction multiply(Fraction f, Fraction g);
    static Fraction divide(Fraction f, Fraction g);

    static int numF();
};

#endif