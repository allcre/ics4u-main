#include "Fraction.h"

int main() {
  int num, dem;

  cout << "enter numerator: ";
  cin >> num;
  cout << "enter denominator: ";
  cin >>  dem;

  Fraction f1;
  Fraction f2(num, dem);
  
  cout << endl << "f1 info (n,d): ";
  cout << f1.getNumerator() << ", " << f1.getDenominator() << endl;

  cout << "f2 info (n,d): ";
  cout << f2.getNumerator() << ", " << f2.getDenominator() << endl;

  cout << endl << "Chaning f2 properties using set methods...";
  f2.setNumerator(5);
  f2.setDenominator(9);

  cout << endl << "f2 new fraction: ";
  cout << f2.toString() << endl;

  cout << endl << "adding f1 to f1 \nnew f1 info (n,d): ";
  f1.add(f1);
  cout << f1.getNumerator() << ", " << f1.getDenominator() << endl;

  cout << endl << "subtracting f1 from f2 \nnew info (n,d): ";
  f2.subtract(f1);
  cout << f2.toString() << endl;

  f2.multiply(f1);
  cout << endl << "multiplying f2 by f1: " << endl << f2.toString() << endl;

  f2.divide(f1);
  cout << endl << "dividing f2 by f1: " << endl << f2.toString() << endl;

  cout << endl << "adding f1 and f2: " << endl <<  Fraction::add(f1, f2).toString() << endl;

  cout << endl << "subtracting f2 from f1: " << endl << Fraction::subtract(f1, f2).toString() << endl;

  cout << endl << "multiplying f1 by f2: " << endl << Fraction::multiply(f1, f2).toString() << endl;

  cout << endl << "dividing f2 by f1: " << endl << Fraction::divide(f2, f1).toString() << endl;
  
  cout << endl << "number of fractions: " << Fraction::numF() << endl;
}