#include "Fraction.h"

int main() {
  int num, dem;

  cout << "enter numerator: ";
  cin >> num;
  cout << "enter denominator: ";
  cin >>  dem;

  Fraction f1;
  Fraction f2(num, dem);
  
  cout << endl << "f1 info (n,d): ";
  cout << f1.getNumerator() << ", " << f1.getDenominator() << endl;

  cout << "f2 info (n,d): ";
  cout << f2.getNumerator() << ", " << f2.getDenominator() << endl;

  cout << endl << "Chaning f2 properties using set methods...";
  f2.setNumerator(-40);
  f2.setDenominator(-9);

  cout << endl << "f2 new fraction: ";
  cout << f2.toString() << endl;
}