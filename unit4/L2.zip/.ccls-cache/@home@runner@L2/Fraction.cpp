#include "Fraction.h"
#include <cstdlib>

Fraction::Fraction() {
  numerator = 1;
  denominator = 2;
}

Fraction::Fraction(int num, int den) {
  setNumerator(num);
  setDenominator(den);
}

int Fraction::getNumerator() {
  return numerator;
}

int Fraction::getDenominator() {
  return denominator;
}

void Fraction::setNumerator(int n) {
  numerator = n;
}

void Fraction::setDenominator(int d) {
  if (d < 0)
    numerator *= -1;
    
  denominator = abs(d);
}

string Fraction::toString() {
  if (denominator == 0)
      return "undefined";
  else
    return (to_string(numerator) + " / " + to_string(denominator));
}